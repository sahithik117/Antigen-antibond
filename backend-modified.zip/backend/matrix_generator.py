import pandas as pd
import numpy as np
import os
from Bio.PDB import PDBParser

# Load dataset
df = pd.read_csv("../data/abag_split.csv")

parser = PDBParser(QUIET=True)

DISTANCE_THRESHOLD = 5.0


def get_residues(chain):

    residues = []

    for residue in chain:

        if residue.id[0] != " ":
            continue

        residues.append(residue)

    return residues


def residue_contact(residue1, residue2):

    for atom1 in residue1:

        for atom2 in residue2:

            distance = atom1 - atom2

            if distance <= DISTANCE_THRESHOLD:
                return True

    return False


# Process rows
for index, row in df.head(20).iterrows():

    pdb_id = row["PDB_ID"]

    pdb_name = pdb_id.replace("pdb_", "").lstrip("0").lower()

    pdb_file = f"../pdb_files/{pdb_name}.pdb"

    print("\nProcessing:", pdb_name)

    if not os.path.exists(pdb_file):

        print("PDB file not found. Skipping.")

        continue

    structure = parser.get_structure(pdb_name, pdb_file)

    model = structure[0]

    print("Chains:", [chain.id for chain in model])

    heavy_chain = str(row["Hchain"])

    light_chain = str(row["Lchain"])

    antigen_chains = str(row["agchains"])

    print("Heavy:", heavy_chain)

    print("Light:", light_chain)

    print("Antigen:", antigen_chains)

    # Check antibody chains
    if heavy_chain not in model or light_chain not in model:

        print("Antibody chains not found. Skipping.")

        continue

    # Check antigen
    if antigen_chains == "nan":

        print("No antigen. Skipping.")

        continue

    # Antibody residues
    antibody_residues = []

    for chain_id in [heavy_chain, light_chain]:

        chain = model[chain_id]

        antibody_residues.extend(
            get_residues(chain)
        )

    # Antigen residues
    antigen_residues = []

    for chain_id in antigen_chains.split("/"):

        chain_id = chain_id.strip()

        if chain_id not in model:

            print(
                "Antigen chain",
                chain_id,
                "not found. Ignoring."
            )

            continue

        chain = model[chain_id]

        antigen_residues.extend(
            get_residues(chain)
        )

    if len(antigen_residues) == 0:

        print("No antigen residues found. Skipping.")

        continue

    # Create matrix
    matrix = np.zeros(
        (
            len(antibody_residues),
            len(antigen_residues)
        ),
        dtype=np.int8
    )

    interaction_count = 0

    # Find interactions
    for i, antibody_residue in enumerate(
        antibody_residues
    ):

        for j, antigen_residue in enumerate(
            antigen_residues
        ):

            if residue_contact(
                antibody_residue,
                antigen_residue
            ):

                matrix[i][j] = 1

                interaction_count += 1

    print("Matrix shape:", matrix.shape)

    print("Interactions:", interaction_count)

    # Save matrix
    output_file = (
        f"../results/interaction_matrix_{pdb_name}.npy"
    )

    np.save(output_file, matrix)

    print("Saved:", output_file)


print("\nDONE")