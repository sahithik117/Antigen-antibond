from Bio.PDB import PDBParser
import numpy as np

# PDB file
pdb_file = "pdb_files/1ejo.pdb"

# Load PDB
parser = PDBParser(QUIET=True)
structure = parser.get_structure("1ejo", pdb_file)

print("PDB loaded successfully!")

# Get first model
models = list(structure.get_models())
model = models[0]

# Get chains
chains = list(model.get_chains())

print("Chains found:")

for chain in chains:
    print("Chain:", chain.id)

# ------------------------------------------------
# IMPORTANT:
# For 1EJO:
# H = Heavy antibody chain
# L = Light antibody chain
# P = Antigen chain
# ------------------------------------------------

antibody_chain = model["H"]
antigen_chain = model["P"]

# Contact distance
DISTANCE_THRESHOLD = 5.0

contacts = []

# Go through antibody residues
for antibody_residue in antibody_chain:

    # Skip water
    if antibody_residue.id[0] != " ":
        continue

    # Go through antigen residues
    for antigen_residue in antigen_chain:

        # Skip water
        if antigen_residue.id[0] != " ":
            continue

        # Compare atoms
        contact_found = False

        for antibody_atom in antibody_residue:
            for antigen_atom in antigen_residue:

                distance = np.linalg.norm(
                    antibody_atom.coord - antigen_atom.coord
                )

                if distance <= DISTANCE_THRESHOLD:
                    contact_found = True
                    break

            if contact_found:
                break

        # Store contact
        if contact_found:

            contacts.append(
                (
                    antibody_residue.id[1],
                    antigen_residue.id[1],
                    antibody_residue.get_resname(),
                    antigen_residue.get_resname()
                )
            )

# ------------------------------------------------
# Print results
# ------------------------------------------------

print()
print("Total contacts:", len(contacts))

print()
print("First 20 contacts:")

for antibody_id, antigen_id, antibody, antigen in contacts[:20]:

    print(
        "Antibody:",
        antibody,
        antibody_id,
        "→ Antigen:",
        antigen,
        antigen_id
    )