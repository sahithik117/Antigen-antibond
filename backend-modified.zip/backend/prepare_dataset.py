import numpy as np
import glob
import os

input_folder = "../results/standardized"
output_file = "../results/dataset.npy"

files = glob.glob(input_folder + "/*.npy")

print("Matrices found:", len(files))

X = []

for file in files:
    matrix = np.load(file)
    X.append(matrix)

X = np.array(X)

print("Dataset shape:", X.shape)

np.save(output_file, X)

print("Dataset saved:", output_file)