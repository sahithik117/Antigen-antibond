import numpy as np
import glob
import os

# Target size
TARGET_ROWS = 431
TARGET_COLS = 129

files = glob.glob("../results/interaction_matrix_*.npy")

os.makedirs("../results/standardized", exist_ok=True)

print("Matrices found:", len(files))

for file in files:

    matrix = np.load(file)

    print("\nProcessing:", os.path.basename(file))
    print("Original shape:", matrix.shape)

    # Create zero matrix of target size
    new_matrix = np.zeros(
        (TARGET_ROWS, TARGET_COLS),
        dtype=np.int8
    )

    # Copy original matrix
    rows = min(matrix.shape[0], TARGET_ROWS)
    cols = min(matrix.shape[1], TARGET_COLS)

    new_matrix[:rows, :cols] = matrix[:rows, :cols]

    # Save
    filename = os.path.basename(file)

    output_file = f"../results/standardized/{filename}"

    np.save(output_file, new_matrix)

    print("New shape:", new_matrix.shape)
    print("Saved:", output_file)

print("\nDONE")