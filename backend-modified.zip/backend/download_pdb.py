import pandas as pd
import requests
import os
import time

# Load dataset
df = pd.read_csv("data/abag_split.csv")

# Keep only rows with antigen information
df = df[df["agchains"].notna()]

# Get unique PDB IDs
pdb_ids = df["PDB_ID"].unique()[:20]

# Create folder
os.makedirs("pdb_files", exist_ok=True)

print("PDBs to download:", len(pdb_ids))

for pdb_id in pdb_ids:

    # Convert dataset ID to RCSB ID
    pdb_name = pdb_id.replace("pdb_", "").lstrip("0").lower()

    # Skip if already downloaded
    output_file = f"pdb_files/{pdb_name}.pdb"

    if os.path.exists(output_file):
        continue

    url = f"https://files.rcsb.org/download/{pdb_name.upper()}.pdb"

    print("Downloading:", pdb_name.upper())

    response = requests.get(url)

    if response.status_code == 200:

        with open(output_file, "wb") as f:
            f.write(response.content)

        print("Saved:", output_file)

    else:

        print("Failed:", pdb_name.upper())

    time.sleep(0.2)

print("DONE")